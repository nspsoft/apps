<script setup>
import { ref, watch, computed } from 'vue';
import { Head, Link, router, useForm, usePage } from '@inertiajs/vue3';
import AppLayout from '@/Layouts/AppLayout.vue';
import { 
    ClockIcon, 
    CalendarIcon, 
    MagnifyingGlassIcon,
    ArrowRightOnRectangleIcon,
    ArrowLeftOnRectangleIcon,
    MapPinIcon,
    UserCircleIcon,
    FunnelIcon,
    CheckCircleIcon,
    ExclamationCircleIcon
} from '@heroicons/vue/24/outline';
import debounce from 'lodash/debounce';

const props = defineProps({
    attendances: Object,
    departments: Array,
    filters: Object,
});

const page = usePage();
const search = ref(props.filters.search);
const date = ref(props.filters.date || new Date().toISOString().split('T')[0]);
const status = ref(props.filters.status);

watch([search, date, status], debounce(() => {
    router.get(route('hr.attendance.index'), { 
        search: search.value, 
        date: date.value, 
        status: status.value 
    }, { preserveState: true, replace: true });
}, 300));

// Find if current login user has an employee record
const currentEmployee = computed(() => {
    // This assumes we have a way to find current user's employee ID
    // For now, we'll let HR record for anyone or build a simple mock
    return page.props.auth?.employee_id || null;
});

const clockInForm = useForm({
    employee_id: '',
    lat: '',
    lng: '',
});

const performClockIn = (employeeId) => {
    if (confirm('Verify Clock-In at current time?')) {
        clockInForm.employee_id = employeeId;
        // Mocking location for now
        clockInForm.lat = '-6.2088';
        clockInForm.lng = '106.8456';
        
        clockInForm.post(route('hr.attendance.clock-in'), {
            onSuccess: () => clockInForm.reset(),
        });
    }
};

const performClockOut = (attendanceId) => {
    if (confirm('Confirm Clock-Out?')) {
        router.post(route('hr.attendance.clock-out', attendanceId));
    }
};

const formatTime = (dateTime) => {
    if (!dateTime) return '--:--';
    return new Date(dateTime).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
};

const getStatusColor = (status) => {
    const colors = {
        present: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
        late: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
        absent: 'text-red-400 bg-red-500/10 border-red-500/20',
        leave: 'text-indigo-400 bg-indigo-500/10 border-indigo-500/20',
    };
    return colors[status] || 'text-slate-500 dark:text-slate-400 bg-slate-500/10 border-slate-500/20';
};
</script>

<template>
    <Head title="Attendance Logs" />
    
    <AppLayout title="HR: Attendance Logs">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <!-- Header -->
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8">
                <div>
                    <h2 class="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">Time & Attendance</h2>
                    <p class="text-sm text-slate-500 mt-1 uppercase tracking-widest font-bold font-mono">Daily Presence Tracking</p>
                </div>
                
                <div class="flex items-center gap-3">
                    <div class="glass-card rounded-2xl px-4 py-2 flex items-center gap-3 shadow-sm">
                        <div class="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></div>
                        <span class="text-xs font-bold text-slate-600 dark:text-slate-300 uppercase tracking-widest font-mono">Live Monitoring</span>
                    </div>
                </div>
            </div>

            <!-- Stats & Quick Actions -->
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
                <!-- Self Clocking Panel (Demo) -->
                <div class="lg:col-span-2 bg-gradient-to-br from-indigo-600/20 to-purple-600/10 border border-indigo-500/20 rounded-[2.5rem] p-8 relative overflow-hidden group">
                    <div class="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
                        <ClockIcon class="h-32 w-32 text-indigo-400" />
                    </div>
                    
                    <div class="relative z-10">
                        <h3 class="text-xl font-bold text-slate-900 dark:text-white mb-2">Daily Timekeeping</h3>
                        <p class="text-sm text-indigo-200/70 max-w-md leading-relaxed mb-8">Record your daily presence. Ensure point of entry and exit are captured accurately for payroll processing.</p>
                        
                        <!-- Manual Entry for Demo (In real app, employee_id would be auto-detected) -->
                        <div class="flex flex-col sm:flex-row items-end gap-4 max-w-xl">
                            <div class="flex-1 w-full space-y-2">
                                <label class="text-[10px] font-bold text-indigo-300 uppercase tracking-widest ml-1">Select Employee (Self-Service Mock)</label>
                                <select v-model="clockInForm.employee_id" class="w-full bg-white dark:bg-slate-950/50 border-indigo-500/30 rounded-2xl py-3 px-4 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/50 transition-all">
                                    <option value="">Choose profile...</option>
                                    <!-- In production this list would be limited or auto-selected -->
                                    <option value="1">Ahmad Subkont (Sample)</option>
                                </select>
                            </div>
                            <button 
                                @click="performClockIn(clockInForm.employee_id)"
                                :disabled="!clockInForm.employee_id || clockInForm.processing"
                                class="w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-2xl bg-indigo-600 px-8 py-3.5 text-sm font-bold text-slate-900 dark:text-white shadow-xl shadow-indigo-900/20 hover:bg-indigo-500 disabled:opacity-50 transition-all hover:-translate-y-0.5"
                            >
                                <ArrowRightOnRectangleIcon class="h-5 w-5" />
                                Record Clock-In
                            </button>
                        </div>
                    </div>
                </div>

                <div class="glass-card rounded-[2.5rem] p-8">
                    <div class="flex items-center justify-between mb-6">
                        <h4 class="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-widest">Today's Summary</h4>
                        <CalendarIcon class="h-5 w-5 text-slate-500" />
                    </div>
                    
                    <div class="space-y-6">
                        <div class="flex items-center justify-between">
                            <div class="flex items-center gap-3">
                                <div class="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
                                    <CheckCircleIcon class="h-5 w-5" />
                                </div>
                                <span class="text-sm font-medium text-slate-600 dark:text-slate-300">Present</span>
                            </div>
                            <span class="text-xl font-bold text-slate-900 dark:text-white font-mono">--</span>
                        </div>
                        <div class="flex items-center justify-between">
                            <div class="flex items-center gap-3">
                                <div class="p-2 rounded-xl bg-amber-500/10 text-amber-400">
                                    <ExclamationCircleIcon class="h-5 w-5" />
                                </div>
                                <span class="text-sm font-medium text-slate-600 dark:text-slate-300">Late</span>
                            </div>
                            <span class="text-xl font-bold text-slate-900 dark:text-white font-mono">--</span>
                        </div>
                        <div class="pt-4 border-t border-slate-200 dark:border-slate-800 flex justify-between items-center">
                            <span class="text-xs text-slate-500 font-bold uppercase tracking-wider">Total Headcount</span>
                            <span class="text-sm font-bold text-slate-500 dark:text-slate-400">--</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Management Table -->
            <div class="glass-card rounded-[2.5rem] overflow-hidden shadow-xl">
                <div class="p-8 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950/50 flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <div class="flex items-center gap-3">
                        <FunnelIcon class="h-5 w-5 text-indigo-400" />
                        <span class="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-widest">Management Logs</span>
                    </div>

                    <div class="flex flex-wrap items-center gap-4">
                        <div class="relative w-full md:w-64">
                            <MagnifyingGlassIcon class="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                            <input v-model="search" type="text" placeholder="Search employee..." class="w-full bg-white dark:bg-slate-950 border-0 rounded-xl py-2.5 pl-10 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/50" />
                        </div>
                        <input v-model="date" type="date" class="bg-white dark:bg-slate-950 border-0 rounded-xl py-2.5 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/50" />
                        <select v-model="status" class="bg-white dark:bg-slate-950 border-0 rounded-xl py-2.5 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/50">
                            <option value="">All Status</option>
                            <option value="present">Present</option>
                            <option value="late">Late</option>
                            <option value="absent">Absent</option>
                            <option value="leave">On Leave</option>
                        </select>
                    </div>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-white dark:bg-slate-950/30">
                                <th class="px-8 py-4 text-[10px] font-bold text-slate-600 uppercase tracking-widest">Employee</th>
                                <th class="px-8 py-4 text-[10px] font-bold text-slate-600 uppercase tracking-widest">Department</th>
                                <th class="px-8 py-4 text-[10px] font-bold text-slate-600 uppercase tracking-widest">Clock In</th>
                                <th class="px-8 py-4 text-[10px] font-bold text-slate-600 uppercase tracking-widest">Clock Out</th>
                                <th class="px-8 py-4 text-[10px] font-bold text-slate-600 uppercase tracking-widest">Status</th>
                                <th class="px-8 py-4 text-[10px] font-bold text-slate-600 uppercase tracking-widest text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
                            <tr v-for="log in attendances.data" :key="log.id" class="hover:bg-slate-50 dark:hover:bg-slate-800/50 dark:bg-slate-800/30 transition-colors group">
                                <td class="px-8 py-5">
                                    <div class="flex items-center gap-3">
                                        <div class="w-10 h-10 rounded-xl bg-slate-50 dark:bg-slate-800 flex items-center justify-center text-xs font-bold text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-slate-700">
                                            {{ log.employee.full_name.charAt(0) }}
                                        </div>
                                        <div>
                                            <div class="text-sm font-bold text-slate-900 dark:text-white">{{ log.employee.full_name }}</div>
                                            <div class="text-[10px] text-slate-500 font-mono font-bold">{{ log.employee.nik }}</div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-8 py-5">
                                    <span class="text-xs font-medium text-slate-500 dark:text-slate-400">{{ log.employee.department?.name }}</span>
                                </td>
                                <td class="px-8 py-5">
                                    <div class="flex items-center gap-2">
                                        <ClockIcon class="h-4 w-4 text-emerald-500/50" />
                                        <span class="text-sm font-mono font-bold text-emerald-400">{{ formatTime(log.clock_in) }}</span>
                                    </div>
                                </td>
                                <td class="px-8 py-5">
                                    <div class="flex items-center gap-2" :class="log.clock_out ? '' : 'opacity-30'">
                                        <ClockIcon class="h-4 w-4 text-blue-500/50" />
                                        <span class="text-sm font-mono font-bold text-blue-400">{{ formatTime(log.clock_out) }}</span>
                                    </div>
                                </td>
                                <td class="px-8 py-5">
                                    <span class="px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider border shadow-sm" :class="getStatusColor(log.status)">
                                        {{ log.status }}
                                    </span>
                                </td>
                                <td class="px-8 py-5 text-right">
                                    <button 
                                        v-if="!log.clock_out"
                                        @click="performClockOut(log.id)"
                                        class="p-2 text-slate-500 dark:text-slate-400 hover:text-blue-400 bg-slate-50 dark:bg-slate-800 hover:bg-blue-400/10 rounded-xl transition-all border border-slate-200 dark:border-slate-700 hover:border-blue-500/30"
                                        title="Force Clock Out"
                                    >
                                        <ArrowLeftOnRectangleIcon class="h-5 w-5" />
                                    </button>
                                </td>
                            </tr>
                            <tr v-if="!attendances.data.length">
                                <td colspan="6" class="px-8 py-16 text-center">
                                    <div class="text-slate-500 text-sm italic">No attendance records found for selected criteria.</div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <!-- Footer / Pagination -->
                <div class="px-8 py-6 bg-white dark:bg-slate-950/20 border-t border-slate-200 dark:border-slate-800 flex justify-center">
                    <nav class="flex gap-1">
                        <Link
                            v-for="(link, i) in attendances.links"
                            :key="i"
                            :href="link.url || '#'"
                            class="px-4 py-2 rounded-xl text-sm font-bold transition-all"
                            :class="[
                                link.active ? 'bg-indigo-600 text-slate-900 dark:text-white shadow-lg shadow-indigo-500/20' : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800/50 dark:bg-slate-800 hover:text-slate-900 dark:text-white',
                                !link.url ? 'opacity-50 cursor-not-allowed' : ''
                            ]"
                            v-html="link.label"
                        />
                    </nav>
                </div>
            </div>
        </div>
    </AppLayout>
</template>

<style scoped>
/* Optional: Style the scrollbar for the table if needed */
</style>




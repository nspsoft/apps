<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class StockAdjustmentItem extends Model
{
    use HasFactory;

    protected $table = 'inv_stock_adjustment_items';

    protected $fillable = [
        'stock_adjustment_id',
        'product_id',
        'qty_system',
        'qty_actual',
        'qty_difference',
    ];

    protected $casts = [
        'qty_system' => 'decimal:4',
        'qty_actual' => 'decimal:4',
        'qty_difference' => 'decimal:4',
    ];

    public function adjustment(): BelongsTo
    {
        return $this->belongsTo(StockAdjustment::class, 'stock_adjustment_id');
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }
}

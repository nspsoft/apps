<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Payroll extends Model
{
    protected $table = 'hr_payrolls';
    protected $fillable = [
        'employee_id', 'period_month', 'period_year', 
        'basic_salary', 'total_allowances', 'total_deductions', 
        'net_salary', 'status', 'payment_date', 'note'
    ];

    protected $casts = [
        'payment_date' => 'datetime',
        'basic_salary' => 'decimal:2',
        'total_allowances' => 'decimal:2',
        'total_deductions' => 'decimal:2',
        'net_salary' => 'decimal:2',
    ];

    public function employee(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(Employee::class);
    }

    public function items(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(PayrollItem::class);
    }
}

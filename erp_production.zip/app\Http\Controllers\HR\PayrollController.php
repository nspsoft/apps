<?php

namespace App\Http\Controllers\HR;

use App\Http\Controllers\Controller;
use App\Models\Payroll;
use App\Models\PayrollItem;
use App\Models\Employee;
use App\Models\Attendance;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class PayrollController extends Controller
{
    public function index(Request $request): Response
    {
        $month = $request->month ?: Carbon::now()->month;
        $year = $request->year ?: Carbon::now()->year;

        $payrolls = Payroll::with(['employee.department', 'employee.position'])
            ->where('period_month', $month)
            ->where('period_year', $year)
            ->when($request->search, function($query, $search) {
                $query->whereHas('employee', function($q) use ($search) {
                    $q->where('full_name', 'like', "%{$search}%")
                      ->orWhere('nik', 'like', "%{$search}%");
                });
            })
            ->paginate(15)
            ->withQueryString();

        return Inertia::render('HR/Payroll/Index', [
            'payrolls' => $payrolls,
            'filters' => [
                'month' => (int)$month,
                'year' => (int)$year,
                'search' => $request->search
            ]
        ]);
    }

    public function generate(Request $request)
    {
        $request->validate([
            'month' => 'required|integer|between:1,12',
            'year' => 'required|integer|min:2020',
        ]);

        $month = $request->month;
        $year = $request->year;
        
        $employees = Employee::where('is_active', true)->get();
        $generatedCount = 0;

        DB::transaction(function () use ($employees, $month, $year, &$generatedCount) {
            foreach ($employees as $employee) {
                // Skip if already generated for this period
                if (Payroll::where('employee_id', $employee->id)->where('period_month', $month)->where('period_year', $year)->exists()) {
                    continue;
                }

                // Basic Logic for Allowance (from Attendance)
                $presenceCount = Attendance::where('employee_id', $employee->id)
                    ->whereMonth('date', $month)
                    ->whereYear('date', $year)
                    ->whereIn('status', ['present', 'late'])
                    ->count();

                $mealAllowance = $presenceCount * 25000; // Sample: 25k per day
                $transportAllowance = $presenceCount * 15000; // Sample: 15k per day
                
                $totalAllowances = $mealAllowance + $transportAllowance;
                $totalDeductions = 0; // TBD: BPJS, etc.

                $payroll = Payroll::create([
                    'employee_id' => $employee->id,
                    'period_month' => $month,
                    'period_year' => $year,
                    'basic_salary' => $employee->basic_salary,
                    'total_allowances' => $totalAllowances,
                    'total_deductions' => $totalDeductions,
                    'net_salary' => $employee->basic_salary + $totalAllowances - $totalDeductions,
                    'status' => 'draft',
                ]);

                // Create Detail Items
                PayrollItem::create([
                    'payroll_id' => $payroll->id,
                    'name' => 'Meal Allowance (' . $presenceCount . ' days)',
                    'amount' => $mealAllowance,
                    'type' => 'allowance'
                ]);

                PayrollItem::create([
                    'payroll_id' => $payroll->id,
                    'name' => 'Transport Allowance (' . $presenceCount . ' days)',
                    'amount' => $transportAllowance,
                    'type' => 'allowance'
                ]);

                $generatedCount++;
            }
        });

        return redirect()->back()->with('success', "Payroll generated for {$generatedCount} employees.");
    }

    public function show(Payroll $payroll): Response
    {
        return Inertia::render('HR/Payroll/Show', [
            'payroll' => $payroll->load(['employee.department', 'employee.position', 'items'])
        ]);
    }

    public function updateStatus(Request $request, Payroll $payroll)
    {
        $request->validate(['status' => 'required|in:confirmed,paid,cancelled']);
        
        $data = ['status' => $request->status];
        if ($request->status === 'paid') {
            $data['payment_date'] = Carbon::now();
        }

        $payroll->update($data);

        return redirect()->back()->with('success', "Payroll status updated to {$request->status}.");
    }

    public function print(Payroll $payroll)
    {
        return view('print.payslip', [
            'payroll' => $payroll->load(['employee.department', 'employee.position', 'items'])
        ]);
    }

    public function publicValidate($id)
    {
        $payroll = Payroll::with(['employee.department', 'employee.position'])
            ->findOrFail($id);

        return view('print.public-payslip-validation', [
            'payroll' => $payroll
        ]);
    }
}

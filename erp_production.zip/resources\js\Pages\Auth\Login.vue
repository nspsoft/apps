<script setup>
import { Head, useForm } from '@inertiajs/vue3';
import { ref, onMounted, onUnmounted } from 'vue';
import { EyeIcon, EyeSlashIcon, LockClosedIcon, EnvelopeIcon, ArrowRightIcon, ArrowDownTrayIcon } from '@heroicons/vue/24/outline';

const form = useForm({
    email: '',
    password: '',
    remember: false,
});

const showPassword = ref(false);
const isLoading = ref(false);

const submit = () => {
    isLoading.value = true;
    form.post('/login', {
        onFinish: () => {
            isLoading.value = false;
        },
    });
};

// PWA Install Prompt
const deferredPrompt = ref(null);
const canInstall = ref(false);

const handleBeforeInstallPrompt = (e) => {
    e.preventDefault();
    window.deferredPrompt = e;
    canInstall.value = true;
};

const installApp = async () => {
    if (!window.deferredPrompt) return;
    window.deferredPrompt.prompt();
    const { outcome } = await window.deferredPrompt.userChoice;
    if (outcome === 'accepted') {
        canInstall.value = false;
        window.deferredPrompt = null;
    }
};

onMounted(() => {
    if (window.deferredPrompt) {
        canInstall.value = true;
    }
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
});

onUnmounted(() => {
    window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
});
</script>

<template>
    <Head title="Login - JICOS ERP" />
    
    <div class="min-h-screen relative overflow-hidden bg-white dark:bg-slate-950 flex items-center justify-center p-4">
        <!-- Floating Install Button -->
        <div v-if="canInstall" class="absolute top-6 right-6 z-50">
            <button 
                @click="installApp"
                class="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 border border-white/10 text-slate-900 dark:text-white hover:bg-white/10 transition-all backdrop-blur-md group"
            >
                <div class="p-1.5 rounded-lg bg-cyan-500/20 text-cyan-400 group-hover:bg-cyan-500 group-hover:text-slate-900 dark:text-white transition-all">
                    <ArrowDownTrayIcon class="h-4 w-4" />
                </div>
                <span class="text-sm font-medium">Install App</span>
            </button>
        </div>
        <!-- Futuristic Data Tunnel Background -->
        <div class="absolute inset-0 overflow-hidden">
            <!-- Deep Space Background -->
            <div class="absolute inset-0 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950"></div>
            
            
            <!-- Perspective Grid Floor -->
            <div class="absolute inset-0" style="perspective: 800px;">
                <div class="grid-floor"></div>
            </div>
            
            <!-- Data Stream Lines -->
            <div class="data-streams">
                <div class="stream stream-1"></div>
                <div class="stream stream-2"></div>
                <div class="stream stream-3"></div>
                <div class="stream stream-4"></div>
                <div class="stream stream-5"></div>
                <div class="stream stream-6"></div>
            </div>
            
            <!-- Glowing Center -->
            <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] bg-cyan-500/10 rounded-full blur-[100px] animate-pulse"></div>
            <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[150px] h-[150px] bg-blue-500/20 rounded-full blur-[50px] animate-pulse" style="animation-delay: 0.5s;"></div>
            
            <!-- Floating Particles -->
            <div class="particle p1"></div>
            <div class="particle p2"></div>
            <div class="particle p3"></div>
            <div class="particle p4"></div>
            <div class="particle p5"></div>
            <div class="particle p6"></div>
            <div class="particle p7"></div>
            <div class="particle p8"></div>
            
            <!-- Corner Glow Effects -->
            <div class="absolute top-0 left-0 w-96 h-96 bg-cyan-500/20 rounded-full blur-[150px] -translate-x-1/2 -translate-y-1/2"></div>
            <div class="absolute bottom-0 right-0 w-96 h-96 bg-blue-600/20 rounded-full blur-[150px] translate-x-1/2 translate-y-1/2"></div>
        </div>

        <!-- Login Card -->
        <div class="relative z-10 w-full max-w-md">
            <!-- Logo & Title -->
            <div class="text-center mb-8">
                <div class="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-cyan-500 via-blue-500 to-indigo-600 shadow-2xl shadow-blue-500/30 mb-6 relative group">
                    <div class="absolute inset-0 rounded-2xl bg-gradient-to-br from-cyan-400 via-blue-400 to-indigo-500 opacity-0 group-hover:opacity-100 transition-opacity blur-xl"></div>
                    <span class="text-3xl font-black text-slate-900 dark:text-white relative z-10">J</span>
                    <div class="absolute -inset-1 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-500 opacity-30 blur-lg animate-pulse"></div>
                </div>
                <h1 class="text-3xl font-bold text-slate-900 dark:text-white mb-2">
                    Welcome to <span class="bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">JICOS</span>
                </h1>
                <p class="text-slate-500 dark:text-slate-400">Jidoka Integrated Control System</p>
            </div>

            <!-- Glass Card -->
            <div class="backdrop-blur-xl bg-white/[0.03] border border-white/10 rounded-3xl p-8 shadow-2xl shadow-black/20 relative overflow-hidden">
                <!-- Card Glow Effect -->
                <div class="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-px bg-gradient-to-r from-transparent via-cyan-500/50 to-transparent"></div>
                
                <form @submit.prevent="submit" class="space-y-6">
                    <!-- Email Field -->
                    <div class="relative group">
                        <label class="block text-sm font-medium text-slate-500 dark:text-slate-400 mb-2">Email Address</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                <EnvelopeIcon class="h-5 w-5 text-slate-500 group-focus-within:text-cyan-400 transition-colors" />
                            </div>
                            <input
                                v-model="form.email"
                                type="email"
                                class="block w-full pl-12 pr-4 py-3.5 rounded-xl border-0 bg-slate-50 dark:bg-slate-900 dark:bg-slate-800/50 text-slate-900 dark:text-white placeholder:text-slate-500 focus:ring-2 focus:ring-cyan-500/50 focus:bg-slate-50 dark:bg-slate-800/80 transition-all"
                                placeholder="admin@jicos.com"
                                required
                            />
                        </div>
                        <p v-if="form.errors.email" class="mt-2 text-sm text-red-400">{{ form.errors.email }}</p>
                    </div>

                    <!-- Password Field -->
                    <div class="relative group">
                        <label class="block text-sm font-medium text-slate-500 dark:text-slate-400 mb-2">Password</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                <LockClosedIcon class="h-5 w-5 text-slate-500 group-focus-within:text-cyan-400 transition-colors" />
                            </div>
                            <input
                                v-model="form.password"
                                :type="showPassword ? 'text' : 'password'"
                                class="block w-full pl-12 pr-12 py-3.5 rounded-xl border-0 bg-slate-50 dark:bg-slate-900 dark:bg-slate-800/50 text-slate-900 dark:text-white placeholder:text-slate-500 focus:ring-2 focus:ring-cyan-500/50 focus:bg-slate-50 dark:bg-slate-800/80 transition-all"
                                placeholder="••••••••"
                                required
                            />
                            <button
                                type="button"
                                @click="showPassword = !showPassword"
                                class="absolute inset-y-0 right-0 pr-4 flex items-center text-slate-500 hover:text-cyan-400 transition-colors"
                            >
                                <EyeSlashIcon v-if="showPassword" class="h-5 w-5" />
                                <EyeIcon v-else class="h-5 w-5" />
                            </button>
                        </div>
                    </div>

                    <!-- Remember & Forgot -->
                    <div class="flex items-center justify-between">
                        <label class="flex items-center gap-2 cursor-pointer group">
                            <input
                                v-model="form.remember"
                                type="checkbox"
                                class="rounded border-slate-600 bg-slate-50 dark:bg-slate-800 text-cyan-500 focus:ring-cyan-500/50 focus:ring-offset-0"
                            />
                            <span class="text-sm text-slate-500 dark:text-slate-400 group-hover:text-slate-600 dark:text-slate-300 transition-colors">Remember me</span>
                        </label>
                        <a href="#" class="text-sm text-cyan-400 hover:text-cyan-300 transition-colors">Forgot password?</a>
                    </div>

                    <!-- Submit Button -->
                    <button
                        type="submit"
                        class="relative w-full py-4 rounded-xl font-semibold text-slate-900 dark:text-white overflow-hidden group disabled:opacity-50 disabled:cursor-not-allowed"
                        :disabled="form.processing"
                    >
                        <!-- Button Gradient Background -->
                        <div class="absolute inset-0 bg-gradient-to-r from-cyan-500 via-blue-500 to-indigo-500 transition-all group-hover:scale-105"></div>
                        
                        <!-- Shimmer Effect -->
                        <div class="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity">
                            <div class="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
                        </div>
                        
                        <!-- Button Content -->
                        <span class="relative flex items-center justify-center gap-2">
                            <span v-if="!form.processing">Sign In</span>
                            <span v-else>Authenticating...</span>
                            <ArrowRightIcon v-if="!form.processing" class="h-5 w-5 group-hover:translate-x-1 transition-transform" />
                            <svg v-else class="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                        </span>
                    </button>
                </form>
            </div>

            <!-- Footer -->
            <div class="text-center mt-8">
                <p class="text-sm text-slate-500">
                    Powered by <span class="text-cyan-400 font-medium">JICOS ERP</span>
                </p>
                <p class="text-xs text-slate-600 mt-1">© 2026 PT SPINDO Tbk. All rights reserved.</p>
            </div>
        </div>
    </div>
</template>

<style scoped>
/* Tunnel Rings */
.tunnel-ring {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    border: 1px solid rgba(6, 182, 212, 0.3);
    border-radius: 50%;
    animation: tunnelExpand 4s linear infinite;
}

.ring-1 { width: 100px; height: 100px; animation-delay: 0s; }
.ring-2 { width: 200px; height: 200px; animation-delay: 0.5s; }
.ring-3 { width: 300px; height: 300px; animation-delay: 1s; }
.ring-4 { width: 400px; height: 400px; animation-delay: 1.5s; }
.ring-5 { width: 500px; height: 500px; animation-delay: 2s; }
.ring-6 { width: 600px; height: 600px; animation-delay: 2.5s; }
.ring-7 { width: 700px; height: 700px; animation-delay: 3s; }
.ring-8 { width: 800px; height: 800px; animation-delay: 3.5s; }

@keyframes tunnelExpand {
    0% {
        transform: translate(-50%, -50%) scale(0.1);
        opacity: 0;
        border-color: rgba(6, 182, 212, 0.8);
    }
    10% {
        opacity: 0.6;
    }
    80% {
        opacity: 0.2;
    }
    100% {
        transform: translate(-50%, -50%) scale(3);
        opacity: 0;
        border-color: rgba(99, 102, 241, 0.1);
    }
}

/* Grid Floor */
.grid-floor {
    position: absolute;
    bottom: 0;
    left: 50%;
    width: 200%;
    height: 50%;
    transform: translateX(-50%) rotateX(70deg);
    transform-origin: center bottom;
    background-image: 
        linear-gradient(rgba(6, 182, 212, 0.15) 1px, transparent 1px),
        linear-gradient(90deg, rgba(6, 182, 212, 0.15) 1px, transparent 1px);
    background-size: 60px 60px;
    animation: gridScroll 2s linear infinite;
}

@keyframes gridScroll {
    0% { background-position: 0 0; }
    100% { background-position: 0 60px; }
}

/* Data Streams */
.data-streams {
    position: absolute;
    inset: 0;
    overflow: hidden;
}

.stream {
    position: absolute;
    width: 2px;
    height: 100px;
    background: linear-gradient(to bottom, transparent, #06b6d4, #3b82f6, transparent);
    animation: streamFall linear infinite;
}

.stream-1 { left: 10%; animation-duration: 2s; animation-delay: 0s; height: 80px; }
.stream-2 { left: 25%; animation-duration: 2.5s; animation-delay: 0.3s; height: 120px; }
.stream-3 { left: 40%; animation-duration: 1.8s; animation-delay: 0.6s; height: 60px; }
.stream-4 { left: 60%; animation-duration: 2.2s; animation-delay: 0.9s; height: 100px; }
.stream-5 { left: 75%; animation-duration: 1.5s; animation-delay: 1.2s; height: 70px; }
.stream-6 { left: 90%; animation-duration: 2.8s; animation-delay: 0.2s; height: 90px; }

@keyframes streamFall {
    0% {
        transform: translateY(-100%) scale(0.5);
        opacity: 0;
    }
    10% {
        opacity: 1;
    }
    90% {
        opacity: 0.8;
    }
    100% {
        transform: translateY(100vh) scale(1.2);
        opacity: 0;
    }
}

/* Floating Particles */
.particle {
    position: absolute;
    width: 4px;
    height: 4px;
    background: #06b6d4;
    border-radius: 50%;
    box-shadow: 0 0 10px #06b6d4, 0 0 20px #06b6d4;
    animation: particleFloat 8s ease-in-out infinite;
}

.p1 { top: 20%; left: 15%; animation-delay: 0s; }
.p2 { top: 30%; right: 20%; animation-delay: 1s; background: #3b82f6; box-shadow: 0 0 10px #3b82f6; }
.p3 { top: 60%; left: 25%; animation-delay: 2s; }
.p4 { top: 70%; right: 15%; animation-delay: 3s; background: #818cf8; box-shadow: 0 0 10px #818cf8; }
.p5 { top: 40%; left: 10%; animation-delay: 4s; }
.p6 { top: 50%; right: 10%; animation-delay: 5s; background: #22d3ee; box-shadow: 0 0 10px #22d3ee; }
.p7 { top: 80%; left: 40%; animation-delay: 6s; }
.p8 { top: 15%; right: 35%; animation-delay: 7s; background: #06b6d4; }

@keyframes particleFloat {
    0%, 100% {
        transform: translate(0, 0) scale(1);
        opacity: 0.6;
    }
    25% {
        transform: translate(20px, -30px) scale(1.2);
        opacity: 1;
    }
    50% {
        transform: translate(-10px, -50px) scale(0.8);
        opacity: 0.8;
    }
    75% {
        transform: translate(15px, -20px) scale(1.1);
        opacity: 1;
    }
}
</style>



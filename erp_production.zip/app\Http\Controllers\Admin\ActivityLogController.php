<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Spatie\Activitylog\Models\Activity;
use App\Models\User;

class ActivityLogController extends Controller
{
    public function index(Request $request)
    {
        $query = Activity::with('causer')
            ->orderBy('created_at', 'desc');

        if ($request->search) {
            $query->where('description', 'like', "%{$request->search}%")
                ->orWhereHas('causer', function ($q) use ($request) {
                    $q->where('name', 'like', "%{$request->search}%");
                });
        }

        if ($request->subject_type) {
            $query->where('subject_type', 'like', "%{$request->subject_type}%");
        }

        $logs = $query->paginate(20)
            ->withQueryString()
            ->through(function ($log) {
                return [
                    'id' => $log->id,
                    'description' => $log->description,
                    'subject_type' => class_basename($log->subject_type),
                    'subject_id' => $log->subject_id,
                    'causer_name' => $log->causer ? $log->causer->name : 'System',
                    'created_at' => $log->created_at->format('Y-m-d H:i:s'),
                    'event' => $log->event,
                    'properties' => $log->properties,
                ];
            });

        $subjectTypes = Activity::select('subject_type')
            ->distinct()
            ->whereNotNull('subject_type')
            ->get()
            ->map(fn($item) => [
                'value' => class_basename($item->subject_type),
                'full_class' => $item->subject_type
            ])
            ->sortBy('value')
            ->values();

        return Inertia::render('Admin/ActivityLogs/Index', [
            'logs' => $logs,
            'filters' => $request->only(['search', 'subject_type']),
            'subjectTypes' => $subjectTypes,
        ]);
    }

    public function show(Activity $activityLog)
    {
        $activityLog->load('causer');

        return Inertia::render('Admin/ActivityLogs/Show', [
            'log' => [
                'id' => $activityLog->id,
                'description' => $activityLog->description,
                'subject_type' => $activityLog->subject_type,
                'subject_id' => $activityLog->subject_id,
                'causer_name' => $activityLog->causer ? $activityLog->causer->name : 'System',
                'created_at' => $activityLog->created_at->format('Y-m-d H:i:s'),
                'properties' => $activityLog->properties,
                'event' => $activityLog->event,
            ]
        ]);
    }
}
